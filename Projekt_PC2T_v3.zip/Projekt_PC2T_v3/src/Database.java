import java.io.*;
import java.util.*;
public class Database {
    private final Map<Integer,AbstStudent> prvkyDatabase;
    Database ()
    {
        prvkyDatabase = new HashMap<Integer, AbstStudent>();
    }
    //vytvoreni noveho studenta
    public boolean setStudent(String jmeno, String prijmeni, int den, int mesic, int rok, int ID, int skupina){
        if(skupina == 1 && prvkyDatabase.put(ID, new Technik(jmeno, prijmeni, den, mesic,rok, ID))==null)
            return true;
        else if(skupina == 2 && prvkyDatabase.put(ID, new Humanitar(jmeno, prijmeni, den, mesic,rok, ID))==null)
            return true;
        else if(skupina == 3 && prvkyDatabase.put(ID, new Kombinak(jmeno, prijmeni, den, mesic,rok, ID))==null)
            return true;
        else
            return false;
    }
    //getter studenta
    public AbstStudent getStudent(int ID){
        return prvkyDatabase.get(ID);
    }
    //getter indexu studenta
    public int getIndex(){
        Set<Integer> seznamID = prvkyDatabase.keySet();
        int index = 0;
        for (Integer ID : seznamID){
            if (prvkyDatabase.get(ID).getID() > index)
                index = prvkyDatabase.get(ID).getID();
        }
        return index;
    }
    //vyhledani daneho studenta dle ID
    public void najdiStudenta(int ID){
        try{
            AbstStudent Student = prvkyDatabase.get(ID);
            if(Student instanceof Technik)
                System.out.println("Obor: Technik ID: "+ID+" Jmeno a Prijmeni: "+Student.getJmeno()+" "+Student.getPrijmeni()+" datum narození: "+Student.getDenNarozeni()+"."+Student.getMesicNarozeni()+"."+Student.getRokNarozeni()+" prumer: "+String.format("%,.2f",Student.getPrumer()));
            else if(Student instanceof Humanitar)
                System.out.println("Obor: Humanitar ID: "+Student.getID()+" Jmeno a Prijmeni: "+Student.getJmeno()+" "+Student.getPrijmeni()+" datum narození: "+Student.getDenNarozeni()+"."+Student.getMesicNarozeni()+"."+Student.getRokNarozeni()+" prumer: "+String.format("%,.2f",Student.getPrumer()));
            else
                System.out.println("Obor: Kombinak ID: "+Student.getID()+" Jmeno a Prijmeni: "+Student.getJmeno()+" "+Student.getPrijmeni()+" datum narození: "+Student.getDenNarozeni()+"."+Student.getMesicNarozeni()+"."+Student.getRokNarozeni()+" prumer: "+String.format("%,.2f",Student.getPrumer()));
        }
        catch (NullPointerException e){
            System.out.println("Student neexistuje");
        }
    }
    //vymazani daneho studenta dle ID
    public boolean vymazStudenta(int ID){
        if (prvkyDatabase.remove(ID)!=null)
            return true;
        return false;
    }
    //celkovy pocet studentu dle oboru
    public void celkovyPocetStudentu(){
        int pocetTechniku = 0;
        int pocetHumanitaru = 0;
        int pocetKombinaku = 0;
        Set<Integer> seznamID = prvkyDatabase.keySet();
        AbstStudent Student;

            for(Integer ID:seznamID){
                Student = prvkyDatabase.get(ID);
                if(Student instanceof Technik){
                    pocetTechniku++;
                }
                else if(Student instanceof Humanitar){
                    pocetHumanitaru++;
                }
                else {
                    pocetKombinaku++;
                }

            }
            System.out.println("Celkovy pocet techniku je: "+pocetTechniku);
            System.out.println("Celkovy pocet humanitaru je: "+pocetHumanitaru);
            System.out.println("Celkovy pocet kombinaku je: "+pocetKombinaku);
        }
    //obecny prumer studentu dle oboru
    public void obecnyPrumer(){
        float soucetPrumeruTechniku = 0;
        float pocetPrumeruTechniku = 0;
        float celkovyPrumerTechniku;
        float soucetPrumeruHumanitaru = 0;
        float pocetPrumeruHumanitaru = 0;
        float celkovyPrumerHumanitaru;
        Set<Integer> seznamID = prvkyDatabase.keySet();
        AbstStudent Student;
        for(Integer ID:seznamID){
            Student = prvkyDatabase.get(ID);
            if(Student instanceof Technik){
                soucetPrumeruTechniku += Student.getPrumer();
                pocetPrumeruTechniku++;
            }
            else if(Student instanceof Humanitar){
                soucetPrumeruHumanitaru += Student.getPrumer();
                pocetPrumeruHumanitaru++;
            }
        }
        celkovyPrumerTechniku = soucetPrumeruTechniku/pocetPrumeruTechniku;
        celkovyPrumerHumanitaru = soucetPrumeruHumanitaru/pocetPrumeruHumanitaru;
        System.out.println("Celkovy prumer techniku je: "+String.format("%,.2f",celkovyPrumerTechniku));
        System.out.println("Celkovy prumer humanitaru je: "+String.format("%,.2f",celkovyPrumerHumanitaru));
    }
    //vypis studentu dle oboru podle abecedy
    public void vypisPodleAbecedy(){
        Set<Integer> seznamID = prvkyDatabase.keySet();
        List<AbstStudent> listStudentuTechniku = new ArrayList<AbstStudent>();
        List<AbstStudent> listStudentuHumanitaru = new ArrayList<AbstStudent>();
        List<AbstStudent> listStudentuKombinaku = new ArrayList<AbstStudent>();
            //abecedni vypis pro Technicky obor
            for (Integer ID : seznamID) {
                if (prvkyDatabase.get(ID) instanceof Technik) {
                    listStudentuTechniku.add(prvkyDatabase.get(ID));
                }
            }
            Collections.sort(listStudentuTechniku, new Comparator<AbstStudent>() {
                @Override
                public int compare(AbstStudent o1, AbstStudent o2) {
                    int porovnani = o1.getPrijmeni().compareTo(o2.getPrijmeni());
                    if(porovnani > 0){
                        return 1;
                    }
                    else if(porovnani < 0){
                        return -1;
                    }
                    else
                        return 0;
                }
            });
            System.out.println("Technicky obor:");
            for (AbstStudent Student : listStudentuTechniku){
                System.out.println("ID: "+Student.getID()+" Jmeno a Prijmeni: "+Student.getJmeno()+" "+Student.getPrijmeni()+" datum narození: "+Student.getDenNarozeni()+"."+Student.getMesicNarozeni()+"."+Student.getRokNarozeni()+" prumer: "+String.format("%,.2f",Student.getPrumer()));
            }
            //abecedni vypis pro Humanitarni obor
            for (Integer ID : seznamID) {
                if (prvkyDatabase.get(ID) instanceof Humanitar) {
                    listStudentuHumanitaru.add(prvkyDatabase.get(ID));
                }
            }
            Collections.sort(listStudentuHumanitaru, new Comparator<AbstStudent>() {
                @Override
                public int compare(AbstStudent o1, AbstStudent o2) {
                    int porovnani = o1.getPrijmeni().compareTo(o2.getPrijmeni());
                    if(porovnani > 0){
                        return 1;
                    }
                    else if(porovnani < 0){
                        return -1;
                    }
                    else
                        return 0;
                }
            });
            System.out.println("Humanitarni obor:");
            for (AbstStudent Student : listStudentuHumanitaru){
                System.out.println("ID: "+Student.getID()+" Jmeno a Prijmeni: "+Student.getJmeno()+" "+Student.getPrijmeni()+" datum narození: "+Student.getDenNarozeni()+"."+Student.getMesicNarozeni()+"."+Student.getRokNarozeni()+" prumer: "+String.format("%,.2f",Student.getPrumer()));
            }
            //abecedni vypis pro Kombinovany obor
            for (Integer ID : seznamID) {
                if (prvkyDatabase.get(ID) instanceof Kombinak) {
                    listStudentuKombinaku.add(prvkyDatabase.get(ID));
                }
            }
            Collections.sort(listStudentuKombinaku, new Comparator<AbstStudent>() {
                @Override
                public int compare(AbstStudent o1, AbstStudent o2) {
                    int porovnani = o1.getPrijmeni().compareTo(o2.getPrijmeni());
                    if(porovnani > 0){
                        return 1;
                    }
                    else if(porovnani < 0){
                        return -1;
                    }
                    else
                        return 0;
                }
            });
            System.out.println("Kombinovany obor:");
            for (AbstStudent Student : listStudentuKombinaku){
                System.out.println("ID: "+Student.getID()+" Jmeno a Prijmeni: "+Student.getJmeno()+" "+Student.getPrijmeni()+" datum narození: "+Student.getDenNarozeni()+"."+Student.getMesicNarozeni()+"."+Student.getRokNarozeni()+" prumer: "+String.format("%,.2f",Student.getPrumer()));
            }
    }
    //zaloha do souboru
    public boolean ulozDoSouboru(String nazevSouboru){
        Locale.setDefault(new Locale("en", "US"));
        Set<Integer> seznamID = prvkyDatabase.keySet();
        try {
            FileWriter fw = new FileWriter(nazevSouboru);
            BufferedWriter out = new BufferedWriter(fw);
            for (Integer ID : seznamID){
                AbstStudent Student = prvkyDatabase.get(ID);
                if(Student instanceof Technik)
                    out.write("1;"+ID+";"+Student.getJmeno()+";"+Student.getPrijmeni()+";"+Student.getDenNarozeni()+";"+Student.getMesicNarozeni()+";"+Student.getRokNarozeni()+";"+String.format("%.2f",Student.getPrumer()));
                else if(Student instanceof Humanitar)
                    out.write("2;"+Student.getID()+";"+Student.getJmeno()+";"+Student.getPrijmeni()+";"+Student.getDenNarozeni()+";"+Student.getMesicNarozeni()+";"+Student.getRokNarozeni()+";"+String.format("%.2f",Student.getPrumer()));
                else
                    out.write("3;"+Student.getID()+";"+Student.getJmeno()+";"+Student.getPrijmeni()+";"+Student.getDenNarozeni()+";"+Student.getMesicNarozeni()+";"+Student.getRokNarozeni()+";"+String.format("%.2f",Student.getPrumer()));
                out.newLine();
            }
            out.close();
            fw.close();
        }
        catch (IOException e){
            System.out.println("Soubor nelze vytvorit");
            return false;
        }
        return true;
    }
    //nahrani zalohy ze souboru
    public boolean nactiZeSouboru(String nazevSouboru){
        FileReader fr = null;
        BufferedReader in = null;
        String radek;
        try {
            fr = new FileReader(nazevSouboru);
            in = new BufferedReader(fr);
            radek = in.readLine();
            String spliter = ";+";
            prvkyDatabase.clear();
            do {
                String[] castiTextu = radek.split(spliter);
                if (castiTextu.length == 8){
                    setStudent(castiTextu[2],castiTextu[3],Integer.parseInt(castiTextu[4]),Integer.parseInt(castiTextu[5]),Integer.parseInt(castiTextu[6]),Integer.parseInt(castiTextu[1]),Integer.parseInt(castiTextu[0]));
                    prvkyDatabase.get(Integer.parseInt(castiTextu[1])).setPrumer(Double.parseDouble(castiTextu[7]));
                }
                radek = in.readLine();
            }
            while (radek != null);
        }
        catch (IOException e){
            System.out.println("Soubor nelze otevrit");
            return false;
        }
        catch (NumberFormatException e) {
            System.out.println("Chyba integrity dat v souboru");
            return false;
        }
        finally
        {
            try
            {	if (in!=null)
                {
                    in.close();
                    fr.close();
                }
            }
            catch (IOException e) {
                System.out.println("Soubor  nelze zavrit");
                return false;
            }
        }
        return true;
    }
}


