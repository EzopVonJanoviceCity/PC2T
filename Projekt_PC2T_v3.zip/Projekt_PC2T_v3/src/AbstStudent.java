public abstract class AbstStudent {
    private final String jmeno;
    private final String prijmeni;
    private final int denNarozeni;
    private final int mesicNarozeni;
    private final int rokNarozeni;
    private final int ID;
    private double pocetZnamek = 0.0;
    private double soucetZnamek = 0.0;
    private double prumer = 0.0;
    //konstruktor
    public AbstStudent(String jmeno, String prijmeni, int denNarozeni, int mesicNarozeni, int rokNarozeni, int ID) {
        this.jmeno = jmeno;
        this.prijmeni = prijmeni;
        this.denNarozeni = denNarozeni;
        this.mesicNarozeni = mesicNarozeni;
        this.rokNarozeni = rokNarozeni;
        this.ID = ID;
    }
    //abstraktni metoda pro dovednost studenta dle oboru
    public abstract void DelejZarvi();
    //funkce pro pridani znamky a vypocitani prumeru
    public void pridejZnamku(int znamka){
        this.pocetZnamek++;
        this.soucetZnamek += znamka;

        if(pocetZnamek != 0.0){
            prumer = soucetZnamek/pocetZnamek;
        }
    }
    //gettery a settery
    public String getJmeno() {
        return jmeno;
    }
    public String getPrijmeni() {
        return prijmeni;
    }
    public int getDenNarozeni() {
        return denNarozeni;
    }
    public int getMesicNarozeni() {
        return mesicNarozeni;
    }
    public int getRokNarozeni() {
        return rokNarozeni;
    }
    public int getID() {
        return ID;
    }
    public double getPrumer() {
        return prumer;
    }
    public void setPrumer(double prumer) {
        this.prumer = prumer;
    }
}
