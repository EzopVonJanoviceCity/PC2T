import java.util.InputMismatchException;
import java.util.Scanner;
public class App {
    public static void main(String[] args) {
        boolean running = true;
        Scanner sc=new Scanner(System.in);
        int volba;
        String jmeno;
        String prijmeni;
        int denNarozeni;
        int mesicNarozeni;
        int rokNarozeni;
        int ID;
        int index;
        int skupina;
        int znamka;
        AbstStudent Student;
        Database mojeDatabase = new Database();

        // umela vypln dat
        mojeDatabase.setStudent("Frantisek", "Benda", 29,11,2004,4,1);
        mojeDatabase.setStudent("Petr", "Vlcek", 25,4,2006,3,1);
        mojeDatabase.setStudent("Jaromir", "Zedka", 24,2,2003,0,1);
        mojeDatabase.setStudent("Jakub", "Chudy", 30,2,2003,1,2);
        mojeDatabase.setStudent("Nikolas", "Kolb", 6,1,1900,2,3);
        mojeDatabase.setStudent("Kaja", "Beranek", 30,2,2003,5,2);
        mojeDatabase.setStudent("Antonin", "Caha", 6,1,1900,6,3);

        while (running){
            System.out.println("Vyberte moznost:");
            System.out.println("1 .. Pridat noveho studenta");
            System.out.println("2 .. Zadat studentovi novou znamku");
            System.out.println("3 .. Propustit studenta z univerzity");
            System.out.println("4 .. Najit studenta dle ID");
            System.out.println("5 .. Dovednost studenta dle ID");
            System.out.println("6 .. Vypis studentu dle abecedy");
            System.out.println("7 .. Vypis obecneho prumeru v technickem a humanitnim oboru");
            System.out.println("8 .. Vypis celkoveho poctu studentu v jednotlivych skupinach");
            System.out.println("9 .. Ulozit udaje do souboru");
            System.out.println("10 .. Nacist udaje ze souboru");
            System.out.println("11 .. Ulozit do SQL databaze");
            System.out.println("12 .. Nacist z SQL databaze");
            System.out.println("13 .. Ukoncit program");
            volba = pouzeCelaCisla(sc);
            switch (volba){
                case 1: ID = mojeDatabase.getIndex() + 1;
                            System.out.println("Zadej jmeno studenta");
                            jmeno = sc.next();
                            System.out.println("Zadej prijmeni studenta");
                            prijmeni = sc.next();
                            do{
                                System.out.println("Zadej den narozeni studenta: 1-31 ");
                                denNarozeni = pouzeCelaCisla(sc);
                                if(denNarozeni < 1 || denNarozeni > 31){
                                    System.out.println("Chybna hodnota");
                                }
                            }
                            while (denNarozeni < 1 || denNarozeni > 31);
                            do{
                                System.out.println("Zadej mesic narozeni studenta: 1-12");
                                mesicNarozeni = pouzeCelaCisla(sc);
                                if(mesicNarozeni < 1 || mesicNarozeni > 12){
                                    System.out.println("Chybna hodnota");
                                }
                            }
                            while (mesicNarozeni < 1 || mesicNarozeni > 12);
                            do{
                                System.out.println("Zadej rok narozeni studenta: 1990-2004");
                                rokNarozeni = pouzeCelaCisla(sc);
                                if(rokNarozeni < 1990 || rokNarozeni > 2004){
                                    System.out.println("Chybna hodnota");
                                }
                            }
                            while (rokNarozeni < 1990 || rokNarozeni > 2004);
                            do{
                                System.out.println("Zadej skupinu studenta:");
                                System.out.println("1 pro Technika, 2 pro Humanitara, 3 pro Kombinaka");
                                skupina = pouzeCelaCisla(sc);
                                if(skupina < 1 || skupina > 3){
                                    System.out.println("Chybna hodnota");
                                }
                            }
                            while (skupina < 1 || skupina > 3);
                            if (!mojeDatabase.setStudent(jmeno, prijmeni, denNarozeni,mesicNarozeni,rokNarozeni,ID,skupina))
                                System.out.println("Student v databazi jiz existuje");
                        break;
                case 2: System.out.println("Zadej ID studenta");
                        index = pouzeCelaCisla(sc);
                        if (mojeDatabase.getStudent(index) != null){
                            do{
                                System.out.println("Zadej novou znamku: 1, 2, 3, 4 nebo 5");
                                znamka = pouzeCelaCisla(sc);
                                if(znamka < 1 || znamka >5){
                                    System.out.println("Chybna hodnota");
                                }
                            }
                            while (znamka < 1 || znamka >5);
                            mojeDatabase.getStudent(index).pridejZnamku(znamka);
                        }
                        else{
                            System.out.println("Student neexistuje");
                        }
                        break;
                case 3: System.out.println("Zadej ID studenta");
                        index = pouzeCelaCisla(sc);
                        Student = mojeDatabase.getStudent(index);
                        if (mojeDatabase.vymazStudenta(index))
                            System.out.println("Student: "+Student.getJmeno()+" "+Student.getPrijmeni()+" ID: " +Student.getID()+ " odstranen ");
                    else
                        System.out.println("Student neexistuje");
                        break;
                case 4: System.out.println("Zadej ID studenta");
                        index = pouzeCelaCisla(sc);
                        mojeDatabase.najdiStudenta(index);
                        break;
                case 5: System.out.println("Zadej ID studenta");
                        index = pouzeCelaCisla(sc);
                        if (mojeDatabase.getStudent(index) != null)
                            mojeDatabase.getStudent(index).DelejZarvi();
                        else
                            System.out.println("Student neexistuje");
                        break;
                case 6: mojeDatabase.vypisPodleAbecedy();
                        break;
                case 7: mojeDatabase.obecnyPrumer();
                        break;
                case 8: mojeDatabase.celkovyPocetStudentu();
                        break;
                case 9: System.out.println("Zadejte jmeno souboru");
                        if (mojeDatabase.ulozDoSouboru(sc.next()))
                            System.out.println("Ulozeno do souboru");
                        else
                            System.out.println("Nebylo ulozeno do souboru");
                        break;
                case 10: System.out.println("Zadejte jmeno souboru");
                         if (mojeDatabase.nactiZeSouboru(sc.next()))
                             System.out.println("Nacteno souboru");
                         else
                             System.out.println("Nenacteno ze souboru");
                         break;
                case 11: System.out.println("11 .. Ulozit do SQL databaze");
                         break;
                case 12: System.out.println("12 .. Nacist z SQL databaze");
                         break;
                case 13: System.out.println("Program ukoncen");
                         running = false;
                         break;
            }
        }
    }
    public static int pouzeCelaCisla(Scanner sc){
        int cislo;
        try{
            cislo = sc.nextInt();
        }
        catch(Exception e){
            System.out.println("zadejte prosim cele cislo ");
            sc.nextLine();
            cislo = pouzeCelaCisla(sc);
        }
        return cislo;
    }
}
