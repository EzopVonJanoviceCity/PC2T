public class Humanitar extends AbstStudent{

    public Humanitar(String jmeno, String prijmeni, int denNarozeni, int mesicNarozeni, int rokNarozeni, int ID) {
        super(jmeno, prijmeni, denNarozeni, mesicNarozeni, rokNarozeni, ID);
    }
    @Override
    //override pro dovednost studenta dle oboru
    public void DelejZarvi() {
        String zverokruh;
        //podminka pro urceni zverokruhu
        if(this.getDenNarozeni()>21 && this.getDenNarozeni()<32 && this.getMesicNarozeni()==12 || this.getDenNarozeni()>0 && this.getDenNarozeni()<21 && this.getMesicNarozeni()==1) {
            zverokruh = "Kozoroha";
        }
        else if(this.getDenNarozeni()>20 && this.getDenNarozeni()<32 && this.getMesicNarozeni()==1 || this.getDenNarozeni()>0 && this.getDenNarozeni()<21 && this.getMesicNarozeni()==2){
            zverokruh = "Vodnare";
        }
        else if(this.getDenNarozeni()>20 && this.getDenNarozeni()<30 && this.getMesicNarozeni()==2 || this.getDenNarozeni()>0 && this.getDenNarozeni()<21 && this.getMesicNarozeni()==3){
            zverokruh = "Ryb";
        }
        else if(this.getDenNarozeni()>20 && this.getDenNarozeni()<32 && this.getMesicNarozeni()==3 || this.getDenNarozeni()>0 && this.getDenNarozeni()<21 && this.getMesicNarozeni()==4){
            zverokruh = "Berana";
        }
        else if(this.getDenNarozeni()>20 && this.getDenNarozeni()<31 && this.getMesicNarozeni()==4 || this.getDenNarozeni()>0 && this.getDenNarozeni()<22 && this.getMesicNarozeni()==5){
            zverokruh = "Byka";
        }
        else if(this.getDenNarozeni()>21 && this.getDenNarozeni()<32 && this.getMesicNarozeni()==5 || this.getDenNarozeni()>0 && this.getDenNarozeni()<22 && this.getMesicNarozeni()==6){
            zverokruh = "Blizencu";
        }
        else if(this.getDenNarozeni()>21 && this.getDenNarozeni()<31 && this.getMesicNarozeni()==6 || this.getDenNarozeni()>0 && this.getDenNarozeni()<23 && this.getMesicNarozeni()==7){
            zverokruh = "Raka";
        }
        else if(this.getDenNarozeni()>22 && this.getDenNarozeni()<32 && this.getMesicNarozeni()==7 || this.getDenNarozeni()>0 && this.getDenNarozeni()<23 && this.getMesicNarozeni()==8){
            zverokruh = "Lva";
        }
        else if(this.getDenNarozeni()>22 && this.getDenNarozeni()<32 && this.getMesicNarozeni()==8 || this.getDenNarozeni()>0 && this.getDenNarozeni()<23 && this.getMesicNarozeni()==9){
            zverokruh = "Panny";
        }
        else if(this.getDenNarozeni()>22 && this.getDenNarozeni()<31 && this.getMesicNarozeni()==9 || this.getDenNarozeni()>0 && this.getDenNarozeni()<24 && this.getMesicNarozeni()==10){
            zverokruh = "Vah";
        }
        else if(this.getDenNarozeni()>23 && this.getDenNarozeni()<32 && this.getMesicNarozeni()==10 || this.getDenNarozeni()>0 && this.getDenNarozeni()<23 && this.getMesicNarozeni()==11){
            zverokruh = "Stira";
        }
        else if(this.getDenNarozeni()>22 && this.getDenNarozeni()<31 && this.getMesicNarozeni()==11 || this.getDenNarozeni()>0 && this.getDenNarozeni()<22 && this.getMesicNarozeni()==12){
            zverokruh = "Strelece";
        }
        else zverokruh = "jineho vesmiru";
        //vypis hodnoty
        System.out.println("Narodil jsem se ve zverokruhu "+ zverokruh);
    }
}
