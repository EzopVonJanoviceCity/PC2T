public class Technik extends AbstStudent{

    public Technik(String jmeno, String prijmeni, int denNarozeni, int mesicNarozeni, int rokNarozeni, int ID) {
        super(jmeno, prijmeni, denNarozeni, mesicNarozeni, rokNarozeni, ID);
    }
    @Override
    //override pro dovednost studenta dle oboru
    public void DelejZarvi() {
        String odpoved;
        //podminka pro prestupny rok
        if(this.getRokNarozeni() % 4 == 0 && this.getRokNarozeni() % 100 != 0 || this.getRokNarozeni() % 400 == 0 && this.getRokNarozeni() % 100 == 0) {
            odpoved = this.getJmeno() + " " + this.getPrijmeni()+": " + "Narodil jsem se v prestupnem roce";
        }
        else odpoved = this.getJmeno() + " " + this.getPrijmeni()+": " + "Nenarodil jsem se v prestupnem roce";
        //vypis hodnoty
        System.out.println(odpoved);
    }
}
